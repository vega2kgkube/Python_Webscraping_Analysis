# temperature_converter.py
celsius = float(input("섭씨 온도를 입력하세요: "))
fahrenheit = celsius * 9/5 + 32
print(f"섭씨 {celsius}도는 화씨 {fahrenheit}도입니다.")