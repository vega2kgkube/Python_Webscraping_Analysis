# list_statistics.py
numbers = [10, 20, 30, 40, 50]
total = sum(numbers)
average = total / len(numbers)

print(f"숫자들: {numbers}")
print(f"합계: {total}")
print(f"평균: {average}")