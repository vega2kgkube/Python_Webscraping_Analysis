# self_introduction.py
name = input("이름을 입력하세요: ")
age = input("나이를 입력하세요: ")
print(f"안녕하세요! 제 이름은 {name}이고, 나이는 {age}살입니다.")