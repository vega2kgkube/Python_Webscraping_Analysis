# string_operations.py
text = input("문자열을 입력하세요: ")
print(f"대문자: {text.upper()}")
print(f"소문자: {text.lower()}")
print(f"문자열 길이: {len(text)}")